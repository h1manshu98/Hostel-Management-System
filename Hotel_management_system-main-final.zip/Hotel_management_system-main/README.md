# Hotel management system

The Hotel Management System Project is a general software
developed to simplify hotel operations by automating them.
the project has Login System security with database in MySql.
This project collects information about customers, room and
other hotel services. you can add user and costomers and delete them and search user as per there name phone no. .
![hotel-management-system](https://user-images.githubusercontent.com/81036521/153882286-ad9f9159-6c6e-4e3e-9e61-a684d733c39f.JPG)

### `# run pip install pillow in cmd or terminal for images if it show some kind of error.`
